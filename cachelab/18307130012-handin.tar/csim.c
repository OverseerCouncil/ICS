/* Guan Xiao 18307130012 */

#include "cachelab.h"
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "getopt.h"
#include "time.h"

struct Line
{
	unsigned int valid;
	unsigned int tag;
	clock_t timeStamp;
};

struct Set
{
	struct Line *lines;
};

struct Cache
{
	unsigned int s;
	unsigned int E;
	unsigned int b;
	struct Set *sets;
};

struct Result
{
	unsigned int hits;
	unsigned int misses;
	unsigned int evictions;
};

struct Cache Initialize(unsigned int s,unsigned int E,unsigned int b)
{
	struct Cache NewCache;
	NewCache.s=s;
	NewCache.E=E;
	NewCache.b=b;
	int S=1<<s;
	if((NewCache.sets=(struct Set*)malloc(S*sizeof(struct Set)))==NULL)
	{
		perror("Failed to create Set in Cache!");
	}
	for(int i=0;i<S;i++)
	{
		if((NewCache.sets[i].lines=(struct Line*)malloc(E*sizeof(struct Line)))==NULL)
		{
			perror("Failed to create Line in Set!");
		}
	}
	return NewCache;
}

void Trash(struct Cache cache)
{
	int S=1<<cache.s;
	for(int i=0;i<S;i++)
	{
		free(cache.sets[i].lines);
	}
}

struct Result HitMissEvi(struct Set TSet,unsigned int tag,unsigned int E,struct Result result,unsigned int flag,unsigned int flag2)
{
	unsigned int hitFlag=0;
	for(unsigned int i=0;i<E;i++)
	{
		if(TSet.lines[i].tag==tag&&TSet.lines[i].valid==1)
		{
			if(flag)
			{
				printf("hit ");
			}
			hitFlag=1;
			result.hits++;
			TSet.lines[i].timeStamp=clock();
			break;
		}
	}
	if(!hitFlag)
	{
		if(flag)
		{
			printf("miss ");
		}
		result.misses++;
		clock_t tempStamp=TSet.lines[0].timeStamp;
		int TempIndex=0;
		for(unsigned int i=0;i<E;i++)
		{
			if(tempStamp>TSet.lines[i].timeStamp)
			{
				tempStamp=TSet.lines[i].timeStamp;
				TempIndex=i;
			}
		}
		TSet.lines[TempIndex].timeStamp=clock();
		TSet.lines[TempIndex].tag=tag;
		if(TSet.lines[TempIndex].valid)
		{
			if(flag)
			{
				printf("eviction ");
			}
			result.evictions++;
		}
		else
		{
			TSet.lines[TempIndex].valid=1;
		}
	}
	if(flag&&flag2==0)
	{
		printf("\n");
	}
	return result;
}

struct Result Test(FILE* fp,struct Cache cache,unsigned int flag)
{
	struct Result result={0,0,0};
	char ch;
	long unsigned int address;
	unsigned int size,b=cache.b,s=cache.s,E=cache.E,S=1<<s;
	while((fscanf(fp,"%c %lx,%d[^\n]",&ch,&address,&size))!=-1)
	{
		if(ch=='I')
		{
			continue;
		}
		else
		{
			unsigned int setIndex=(address>>b)&(S-1);
			unsigned int tag=(address>>b)>>s;
			struct Set TSet=cache.sets[setIndex];
			if(ch=='L'||ch=='S')
			{
				if(flag)
				{
					printf("%c %lx %d ",ch,address,size);
				}
				result=HitMissEvi(TSet,tag,E,result,flag,0);
			}
			else if(ch=='M')
			{
				if(flag)
				{
					printf("%c %lx %d ",ch,address,size);
				}
				result=HitMissEvi(TSet,tag,E,result,flag,1);
				result=HitMissEvi(TSet,tag,E,result,flag,0);
			}
			else
			{
				continue;
			}
		}
	}
	return result;
}

int main(int argc,char *argv[])
{
	struct Result Results={0,0,0};
	struct Cache SimCache={0,0,0,NULL};
	FILE *fp=NULL;
	unsigned int s=0,b=0,E=0,flag=0;
	const char *commandOptions="hvs:E:b:t:";
	char ch;
	while((ch=getopt(argc,argv,commandOptions))!=-1)
	{
		switch(ch)
		{
			case 'h':
				printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file>\n");
  				printf("Options\n");
  				printf("  -h        Print this help message.\n");
  				printf("  -v        Optional verbose flag.\n");
  				printf("  -s <num>: Number of set index bits.\n");
  				printf("  -E <num>: Number of lines per set.\n");
  				printf("  -b <num>: Number of block offset bits.\n");
  				printf("  -t <file>: Trace file.\n");
  				printf("\n");
  				printf("Exampes:\n");
  				printf("  linux> ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n");
  				printf("  linux> ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
				exit(EXIT_SUCCESS);
			case 'v':
				flag=1;
				break;
			case 's':
				s=atol(optarg);
				break;
			case 'E':
				E=atol(optarg);
				break;
			case 'b':
				b=atol(optarg);
				break;
			case 't':
				if((fp=fopen((const char *)optarg,"r"))==NULL)
				{
					perror("Failed to open tracefile!");
					exit(EXIT_FAILURE);
				}
				break;
			default:
				exit(EXIT_FAILURE);
		}
	}
	if(s==0||E==0||b==0||fp==NULL)
	{
		printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file>\n");
  		printf("Options\n");
  		printf("  -h        Print this help message.\n");
  		printf("  -v        Optional verbose flag.\n");
  		printf("  -s <num>: Number of set index bits.\n");
  		printf("  -E <num>: Number of lines per set.\n");
  		printf("  -b <num>: Number of block offset bits.\n");
  		printf("  -t <file>: Trace file.\n");
  		printf("\n");
  		printf("Exampes:\n");
  		printf("  linux> ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n");
  		printf("  linux> ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
		exit(EXIT_SUCCESS);
	}
	SimCache=Initialize(s,E,b);
	Results=Test(fp,SimCache,flag);
    printSummary(Results.hits,Results.misses,Results.evictions);
	Trash(SimCache);
    return 0;
}
